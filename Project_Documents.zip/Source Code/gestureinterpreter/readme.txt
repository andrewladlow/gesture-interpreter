The project code was created using the Eclipse IDE with Java JRE 8. The use of Eclipse (or an IDE with Eclipse project support) is therefore recommended to import the project.

The project requires Leap Motion libraries - libraries for Windows x64 and OSX are included in the /lib/ directory. Instructions are provided in the link below to import these libraries, if necessary. 

https://developer.leapmotion.com/documentation/java/devguide/Project_Setup.html 